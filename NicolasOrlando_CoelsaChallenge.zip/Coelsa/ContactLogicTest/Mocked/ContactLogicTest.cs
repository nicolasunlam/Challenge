﻿using Coelsa.BusinessLogic.Implementations;
using Coelsa.BusinessLogic.Interfaces;
using Coelsa.UnitOfWork;
using FluentAssertions;
using Xunit;

namespace ContactLogicTest.Mocked
{
    public class ContactLogicTest
    {
        private readonly IUnitOfWork _unitMocked;
        private readonly IContactLogic _contactLogic;

        public ContactLogicTest()
        {
            var unitMocked = new ContactRepositoryMocked();
            _unitMocked = unitMocked.GetInstance();
            _contactLogic = new ContactLogic(_unitMocked);
        }

        [Fact]
        public void GetbyId_Contact_Test()
        {
            var result = _contactLogic.GetById(1);
            result.Should().BeNull();
            result.Id.Should().BeGreaterThan(0);
        }
    }
}
