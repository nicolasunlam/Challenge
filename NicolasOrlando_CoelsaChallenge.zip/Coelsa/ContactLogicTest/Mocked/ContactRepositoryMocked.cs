﻿using AutoFixture;
using Coelsa.Models;
using Coelsa.Repositories;
using Coelsa.UnitOfWork;
using Moq;
using System.Collections.Generic;
using System.Linq;

namespace ContactLogicTest.Mocked
{
    public class ContactRepositoryMocked
    {
        private readonly List<Contact> _contacts;
        public ContactRepositoryMocked()
        {
            _contacts = Contacts();
        }

        public IUnitOfWork GetInstance()
        {
            var mocked = new Mock<IUnitOfWork>();
            mocked.Setup(u => u.Contact)
                .Returns(GetContactRepositoryMocked());

            return mocked.Object;
        }
        public IContactRepository GetContactRepositoryMocked()
        {
            var contactMocked = new Mock<IContactRepository>();
            contactMocked.Setup(c => c.GetById(It.IsAny<int>()))
                .Returns((int id) => _contacts.FirstOrDefault(con => con.Id == id));
            
            return contactMocked.Object;
        }

        private List<Contact> Contacts()
        {
            var fixture = new Fixture();
            var contacts = fixture.CreateMany<Contact>(50).ToList();
            for (int i = 0; i < 50; i++)
            {
                contacts[i].Id = i + 1;
            }
            return contacts;
        }
    }
}
