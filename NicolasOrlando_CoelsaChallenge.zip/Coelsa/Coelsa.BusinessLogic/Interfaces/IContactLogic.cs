﻿using Coelsa.Models;
using System.Collections.Generic;

namespace Coelsa.BusinessLogic.Interfaces
{
    public interface IContactLogic
    {
        Contact GetById(int id);
        IEnumerable<Contact> ContactPagedList(int page, int rows);
        int Insert(Contact contact);
        bool Update(Contact contact);
        bool Delete(Contact contact);

    }
}
