﻿using Coelsa.BusinessLogic.Interfaces;
using Coelsa.Models;
using Coelsa.UnitOfWork;
using System.Collections.Generic;

namespace Coelsa.BusinessLogic.Implementations
{
    public class ContactLogic : IContactLogic
    {
        private readonly IUnitOfWork _unitOfWork;
        public ContactLogic(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IEnumerable<Contact> ContactPagedList(int page, int rows)
        {
            return _unitOfWork.Contact.ContactPagedList(page, rows);
        }

        public bool Delete(Contact contact)
        {
            return _unitOfWork.Contact.Delete(contact);
        }

        public Contact GetById(int id)
        {
            return _unitOfWork.Contact.GetById(id);
        }

        public int Insert(Contact contact)
        {
            return _unitOfWork.Contact.Insert(contact);
        }

        public bool Update(Contact contact)
        {
            return _unitOfWork.Contact.Update(contact);
        }
    }
}
