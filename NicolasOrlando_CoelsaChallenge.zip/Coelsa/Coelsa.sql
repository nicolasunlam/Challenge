CREATE DATABASE Coelsa
GO 

USE Coelsa
GO

/*==============================================================*/
/* Table: Contact                                           */
/*==============================================================*/
create table Contact (
   Id                   int                  identity,
   FirstName            nvarchar(40)         not null,
   LastName             nvarchar(40)         not null,
   Company              nvarchar(40)         null,
   Email				nvarchar(40)         null,
   PhoneNumber			nvarchar(20)         null,
   constraint PK_CONTACT primary key (Id)
)
go

CREATE PROCEDURE [dbo].[ContactPagedList]  
@page int,  
@rows int

AS 
BEGIN  

 SELECT [Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber],
 COUNT(*) OVER() TotalRecords
 FROM [Contact]
 order by [Id]
 OFFSET @page ROWS                  
 FETCH NEXT @rows ROWS ONLY
 
END
go

USE Coelsa
GO

SET IDENTITY_INSERT Contact ON
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(1,'Maria','Anders','Company1','email1@email.com','030-0074321')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(2,'Ana','Trujillo','Company2','email2@email.com','(5) 555-4729')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(3,'Antonio','Moreno','Company3','email3@email.com','(5) 555-3932')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(4,'Thomas','Hardy','Company4','email4@email.com','(171) 555-7788')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(5,'Christina','Berglund','Company5','email5@email.com','0921-12 34 65')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(6,'Hanna','Moos','Company6','email6@email.com','0621-08460')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(7,'Fr�d�rique','Citeaux','Company7','email7@email.com','88.60.15.31')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(8,'Mart�n','Sommer','Company8','email8@email.com','(91) 555 22 82')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(9,'Laurence','Lebihan','Company9','email9@email.com','91.24.45.40')
INSERT INTO [Contact] ([Id]  ,[FirstName] ,[LastName] ,[Company],[Email],[PhoneNumber])VALUES(10,'Elizabeth','Lincoln','Company10','email10@email.com','(604) 555-4729')

