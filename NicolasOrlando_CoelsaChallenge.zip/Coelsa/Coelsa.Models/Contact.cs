﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Coelsa.Models
{
    public class Contact
    {
        public int Id { get; set; }
        [DisplayName("FirstName")]
        [Required]
        [StringLength(40)]
        public string FirstName { get; set; }
        [DisplayName("LastName")]
        [Required]
        [StringLength(40)]
        public string LastName { get; set; }
        [DisplayName("Company")]
        [Required]
        [StringLength(40)]
        public string Company { get; set; }
        [DisplayName("Email")]
        [Required]
        [StringLength(40)]
        public string Email { get; set; }
        [DisplayName("PhoneNumber")]
        [Required]
        [StringLength(40)]
        public string PhoneNumber { get; set; }
    }
}
