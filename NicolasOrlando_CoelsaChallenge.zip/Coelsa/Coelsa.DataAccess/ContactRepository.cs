﻿using Coelsa.Models;
using Coelsa.Repositories;
using Dapper;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Coelsa.DataAccess
{
    public class ContactRepository : Repository<Contact>, IContactRepository
    {
        public ContactRepository(string connectionString) : base(connectionString)
        {

        }

        public IEnumerable<Contact> ContactPagedList(int page, int rows)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@page", page);
            parameters.Add("@rows", rows);

            using (var connection = new SqlConnection(_connectionString))
            {
                return connection.Query<Contact>("dbo.ContactPagedList",
                                                  parameters,
                                                  commandType: System.Data.CommandType.StoredProcedure);
            }
        }
    }
}
