﻿using Coelsa.Repositories;
using Coelsa.UnitOfWork;

namespace Coelsa.DataAccess
{
    public class CoelsaUnitOfWork : IUnitOfWork
    {
        public CoelsaUnitOfWork(string connectionString)
        {
            Contact = new ContactRepository(connectionString);
        }
        public IContactRepository Contact { get; private set; }
    }
}
