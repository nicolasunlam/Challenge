﻿using Coelsa.Repositories;

namespace Coelsa.UnitOfWork
{
    public interface IUnitOfWork
    {
        IContactRepository Contact { get; }
    }
}
