﻿using Coelsa.BusinessLogic.Interfaces;
using Coelsa.Models;
using Microsoft.AspNetCore.Mvc;

namespace Coelsa.WebApi.Controllers
{
    [Route("api/Contacts")]
    public class ContactsController : Controller
    {
        private readonly IContactLogic _logic;
        public ContactsController(IContactLogic logic)
        {
            _logic = logic;
        }

        [HttpGet]
        [Route("GetPaginatedContact/{id:int}/{rows:int}")]
        public IActionResult GetPaginatedContact(int page, int rows)
        {
            return Ok(_logic.ContactPagedList(page, rows));
        }

        [HttpGet]
        [Route("{id:int}")]
        public IActionResult GetById(int id)
        {
            return Ok(_logic.GetById(id));
        }

        [HttpPost]
        public IActionResult Post([FromBody] Contact contact)
        {
            if (!ModelState.IsValid) return BadRequest();
            return Ok(_logic.Insert(contact));
        }

        [HttpPut]
        public IActionResult Put([FromBody] Contact contact)
        {
            if (ModelState.IsValid && _logic.Update(contact))
            {
                return Ok(new { Message = "Contact Updated" });
            }
            return BadRequest();
        }

        [HttpDelete]
        public IActionResult Delete([FromBody] Contact contact)
        {
            if (contact.Id > 0)
                return Ok(_logic.Delete(contact));
            return BadRequest();
        }
    }
}
