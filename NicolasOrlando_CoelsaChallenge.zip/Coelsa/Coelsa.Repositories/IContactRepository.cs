﻿using Coelsa.Models;
using System.Collections.Generic;

namespace Coelsa.Repositories
{
    public interface IContactRepository : IRepository<Contact>
    {
        IEnumerable<Contact> ContactPagedList(int page, int rows);
    }
}
